/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2005                    */
/* Created on:     5/6/2019 2:08:40 PM                          */
/*==============================================================*/


if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('DESTINATION') and o.name = 'FK_DESTINAT_HAS_FLIGHT_I')
alter table DESTINATION
   drop constraint FK_DESTINAT_HAS_FLIGHT_I
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('HAVE') and o.name = 'FK_HAVE_HAVE_FLIGHT_I')
alter table HAVE
   drop constraint FK_HAVE_HAVE_FLIGHT_I
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('HAVE') and o.name = 'FK_HAVE_HAVE2_AIRCRAFT')
alter table HAVE
   drop constraint FK_HAVE_HAVE2_AIRCRAFT
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('TICKET') and o.name = 'FK_TICKET_CAN_HAVE_DISCOUNT')
alter table TICKET
   drop constraint FK_TICKET_CAN_HAVE_DISCOUNT
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('TICKET') and o.name = 'FK_TICKET_FOR_FLIGHT_I')
alter table TICKET
   drop constraint FK_TICKET_FOR_FLIGHT_I
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('TICKET') and o.name = 'FK_TICKET_GET_EMPLOYEE')
alter table TICKET
   drop constraint FK_TICKET_GET_EMPLOYEE
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('TICKET') and o.name = 'FK_TICKET_MAKE_PASSENGE')
alter table TICKET
   drop constraint FK_TICKET_MAKE_PASSENGE
go

if exists (select 1
            from  sysobjects
           where  id = object_id('AIRCRAFT')
            and   type = 'U')
   drop table AIRCRAFT
go

if exists (select 1
            from  sysobjects
           where  id = object_id('DEPENDANT_OF')
            and   type = 'U')
   drop table DEPENDANT_OF
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('DESTINATION')
            and   name  = 'HAS_FK'
            and   indid > 0
            and   indid < 255)
   drop index DESTINATION.HAS_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('DESTINATION')
            and   type = 'U')
   drop table DESTINATION
go

if exists (select 1
            from  sysobjects
           where  id = object_id('DISCOUNT')
            and   type = 'U')
   drop table DISCOUNT
go

if exists (select 1
            from  sysobjects
           where  id = object_id('EMPLOYEE')
            and   type = 'U')
   drop table EMPLOYEE
go

if exists (select 1
            from  sysobjects
           where  id = object_id('FLIGHT_INFO')
            and   type = 'U')
   drop table FLIGHT_INFO
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('HAVE')
            and   name  = 'HAVE2_FK'
            and   indid > 0
            and   indid < 255)
   drop index HAVE.HAVE2_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('HAVE')
            and   name  = 'HAVE_FK'
            and   indid > 0
            and   indid < 255)
   drop index HAVE.HAVE_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('HAVE')
            and   type = 'U')
   drop table HAVE
go

if exists (select 1
            from  sysobjects
           where  id = object_id('PASSENGER')
            and   type = 'U')
   drop table PASSENGER
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('TICKET')
            and   name  = 'CAN_HAVE_FK'
            and   indid > 0
            and   indid < 255)
   drop index TICKET.CAN_HAVE_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('TICKET')
            and   name  = 'FOR_FK'
            and   indid > 0
            and   indid < 255)
   drop index TICKET.FOR_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('TICKET')
            and   name  = 'GET_FK'
            and   indid > 0
            and   indid < 255)
   drop index TICKET.GET_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('TICKET')
            and   name  = 'MAKE_FK'
            and   indid > 0
            and   indid < 255)
   drop index TICKET.MAKE_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('TICKET')
            and   type = 'U')
   drop table TICKET
go

/*==============================================================*/
/* Table: AIRCRAFT                                              */
/*==============================================================*/
create table AIRCRAFT (
   AIRCRAFTID           int                  not null,
   CAPACITY             bigint               not null,
   FLIGHT_ID            int                  not null,
   DATE                 datetime             not null,
   constraint PK_AIRCRAFT primary key nonclustered (AIRCRAFTID)
)
go

/*==============================================================*/
/* Table: DEPENDANT_OF                                          */
/*==============================================================*/
create table DEPENDANT_OF (
   FNAME                varchar(100)         null,
   LNAME                varchar(100)         null,
   AGE                  int                  null,
   NATIONALITY          varchar(100)         null
)
go

/*==============================================================*/
/* Table: DESTINATION                                           */
/*==============================================================*/
create table DESTINATION (
   FFLIGHT_ID           int                  not null,
   DESTINATION          varchar(400)         not null,
   FLIGHTID             int                  not null,
   constraint PK_DESTINATION primary key nonclustered (FFLIGHT_ID, DESTINATION)
)
go

/*==============================================================*/
/* Index: HAS_FK                                                */
/*==============================================================*/
create index HAS_FK on DESTINATION (
FLIGHTID ASC
)
go

/*==============================================================*/
/* Table: DISCOUNT                                              */
/*==============================================================*/
create table DISCOUNT (
   DISCOUNTID           int                  not null,
   DISCOUNT_TITLE       varchar(100)         not null,
   AMOUNT               bigint               not null,
   constraint PK_DISCOUNT primary key nonclustered (DISCOUNTID)
)
go

/*==============================================================*/
/* Table: EMPLOYEE                                              */
/*==============================================================*/
create table EMPLOYEE (
   EMPLOYEEID           int                  not null,
   MOBILE_NO            bigint               not null,
   DESIGNATION          varchar(100)         not null,
   F_NAME               varchar(200)         not null,
   L_NAME               varchar(200)         not null,
   constraint PK_EMPLOYEE primary key nonclustered (EMPLOYEEID)
)
go

/*==============================================================*/
/* Table: FLIGHT_INFO                                           */
/*==============================================================*/
create table FLIGHT_INFO (
   FLIGHTID             int                  not null,
   DATE                 datetime             not null,
   constraint PK_FLIGHT_INFO primary key nonclustered (FLIGHTID)
)
go

/*==============================================================*/
/* Table: HAVE                                                  */
/*==============================================================*/
create table HAVE (
   FLIGHTID             int                  not null,
   AIRCRAFTID           int                  not null,
   constraint PK_HAVE primary key (FLIGHTID, AIRCRAFTID)
)
go

/*==============================================================*/
/* Index: HAVE_FK                                               */
/*==============================================================*/
create index HAVE_FK on HAVE (
FLIGHTID ASC
)
go

/*==============================================================*/
/* Index: HAVE2_FK                                              */
/*==============================================================*/
create index HAVE2_FK on HAVE (
AIRCRAFTID ASC
)
go

/*==============================================================*/
/* Table: PASSENGER                                             */
/*==============================================================*/
create table PASSENGER (
   PASSENGERID          int                  not null,
   AGE                  int                  not null,
   NATIONALITY          varchar(100)         not null,
   MOBILENO_            bigint               not null,
   FNAME                varchar(100)         not null,
   LNAME                varchar(100)         not null,
   COUNTRY              varchar(100)         not null,
   CITY                 varchar(100)         not null,
   STREET               varchar(100)         not null,
   constraint PK_PASSENGER primary key nonclustered (PASSENGERID)
)
go

/*==============================================================*/
/* Table: TICKET                                                */
/*==============================================================*/
create table TICKET (
   TICKETID             int                  not null,
   FLIGHTID             int                  null,
   PASSENGERID          int                  not null,
   EMPLOYEEID           int                  not null,
   DISCOUNTID           int                  null,
   BOOKING_DATE         datetime             not null,
   constraint PK_TICKET primary key nonclustered (TICKETID)
)
go

/*==============================================================*/
/* Index: MAKE_FK                                               */
/*==============================================================*/
create index MAKE_FK on TICKET (
PASSENGERID ASC
)
go

/*==============================================================*/
/* Index: GET_FK                                                */
/*==============================================================*/
create index GET_FK on TICKET (
EMPLOYEEID ASC
)
go

/*==============================================================*/
/* Index: FOR_FK                                                */
/*==============================================================*/
create index FOR_FK on TICKET (
FLIGHTID ASC
)
go

/*==============================================================*/
/* Index: CAN_HAVE_FK                                           */
/*==============================================================*/
create index CAN_HAVE_FK on TICKET (
DISCOUNTID ASC
)
go

alter table DESTINATION
   add constraint FK_DESTINAT_HAS_FLIGHT_I foreign key (FLIGHTID)
      references FLIGHT_INFO (FLIGHTID)
go

alter table HAVE
   add constraint FK_HAVE_HAVE_FLIGHT_I foreign key (FLIGHTID)
      references FLIGHT_INFO (FLIGHTID)
go

alter table HAVE
   add constraint FK_HAVE_HAVE2_AIRCRAFT foreign key (AIRCRAFTID)
      references AIRCRAFT (AIRCRAFTID)
go

alter table TICKET
   add constraint FK_TICKET_CAN_HAVE_DISCOUNT foreign key (DISCOUNTID)
      references DISCOUNT (DISCOUNTID)
go

alter table TICKET
   add constraint FK_TICKET_FOR_FLIGHT_I foreign key (FLIGHTID)
      references FLIGHT_INFO (FLIGHTID)
go

alter table TICKET
   add constraint FK_TICKET_GET_EMPLOYEE foreign key (EMPLOYEEID)
      references EMPLOYEE (EMPLOYEEID)
go

alter table TICKET
   add constraint FK_TICKET_MAKE_PASSENGE foreign key (PASSENGERID)
      references PASSENGER (PASSENGERID)
go

