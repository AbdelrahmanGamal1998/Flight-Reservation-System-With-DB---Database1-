﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reservation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'reservationDataSet.AIRCRAFT' table. You can move, or remove it, as needed.
            this.aIRCRAFTTableAdapter.Fill(this.reservationDataSet.AIRCRAFT);
            SqlConnection sqlConnection = new SqlConnection("Data Source=DESKTOP-92P162H\\SQLEXPRESS;Initial Catalog=Reservation;Integrated Security=True");


        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Form3 Form3 = new Form3();
            Form3.Show();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();

            con.ConnectionString = "Data Source=DESKTOP-92P162H\\SQLEXPRESS;Initial Catalog= Reservation;Integrated Security=True";
            SqlCommand cmd = new SqlCommand("Insert Into AIRCRAFT values ( '" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox10.Text + "')", con);

            con.Open();
            MessageBox.Show(cmd.CommandText);
            cmd.ExecuteNonQuery();
            con.Close();


        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();

            con.ConnectionString = "Data Source=DESKTOP-92P162H\\SQLEXPRESS;Initial Catalog= Reservation;Integrated Security=True";
            SqlCommand cmd = new SqlCommand("Insert Into EMPLOYEE values ( '" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + textBox8.Text + "','" + textBox9.Text + "')", con);

            con.Open();
            MessageBox.Show(cmd.CommandText);
            cmd.ExecuteNonQuery();
            con.Close();

        }

        private void Button4_Click(object sender, EventArgs e)
        {

            SqlConnection SqlConnection = new SqlConnection("Data Source=DESKTOP-92P162H\\SQLEXPRESS;Initial Catalog=Reservation;Integrated Security=True");

            SqlCommand sqlcommand = new SqlCommand();
            sqlcommand.Connection = SqlConnection;
            SqlConnection.Open();
            sqlcommand.CommandText = "UPDATE AIRCRAFT SET CAPACITY ='" + textBox4.Text + "' WHERE AIRCRAFTID = '" + textBox11.Text + "'";
            sqlcommand.ExecuteNonQuery();
            SqlConnection.Close();
            MessageBox.Show("UPDATE SUCESSFULLY");
        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }

        private void Button5_Click(object sender, EventArgs e)
        {
            SqlConnection SqlConnection = new SqlConnection("Data Source=DESKTOP-92P162H\\SQLEXPRESS;Initial Catalog=Reservation;Integrated Security=True");

            SqlCommand sqlcommand = new SqlCommand();
            sqlcommand.Connection = SqlConnection;
            SqlConnection.Open();
            sqlcommand.CommandText = "Delete from aircraft where AIRCRAFTID = '" + textBox12.Text + "'";
            sqlcommand.ExecuteNonQuery();
            SqlConnection.Close();
            MessageBox.Show("DELETED SUCESSFULLY");
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            Form2 Form2 = new Form2();
            Form2.Show();
        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }
    }
}
