﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reservation
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void DISCOUNTBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.dISCOUNTBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.reservationDataSet);

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'reservationDataSet.AIRCRAFT' table. You can move, or remove it, as needed.
            this.aIRCRAFTTableAdapter.Fill(this.reservationDataSet.AIRCRAFT);
            // TODO: This line of code loads data into the 'reservationDataSet.DISCOUNT' table. You can move, or remove it, as needed.
            this.dISCOUNTTableAdapter.Fill(this.reservationDataSet.DISCOUNT);

        }
    }
}
