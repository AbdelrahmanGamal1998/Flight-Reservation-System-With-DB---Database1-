﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reservation
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection sqlConnection = new SqlConnection("Data Source=DESKTOP-92P162H\\SQLEXPRESS;Initial Catalog=Reservation;Integrated Security=True");


        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=DESKTOP-92P162H\SQLEXPRESS;Initial Catalog=Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand com = new SqlCommand();

            com.CommandText = "select FLIGHT_INFO.DATE,AIRCRAFT.CAPACITY  from  FLIGHT_INFO, AIRCRAFT where AIRCRAFT.FLIGHT_ID = FLIGHT_INFO.FLIGHTID";

            com.Connection = con;

            com.CommandType = CommandType.Text;

            SqlDataReader reader = com.ExecuteReader();

            string data = "";

            while (reader.Read())
            {
                data += reader[0];//one column
                data += "  ";
                data += reader[1];
                data += Environment.NewLine;
            }

            MessageBox.Show(data);
            reader.Close();
            con.Close();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            SqlConnection SqlConnection = new SqlConnection("Data Source=DESKTOP-92P162H\\SQLEXPRESS;Initial Catalog=Reservation;Integrated Security=True");

            SqlCommand sqlcommand = new SqlCommand();
            sqlcommand.Connection = SqlConnection;
            SqlConnection.Open();
            sqlcommand.CommandText = "UPDATE EMPLOYEE SET L_NAME ='" + textBox2.Text + "' WHERE EMPLOYEEID = '" + textBox1.Text + "'";
            sqlcommand.ExecuteNonQuery();
            SqlConnection.Close();
            MessageBox.Show("UPDATE SUCESSFULLY");
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button3_Click(object sender, EventArgs e)
        {
            SqlConnection SqlConnection = new SqlConnection("Data Source=DESKTOP-92P162H\\SQLEXPRESS;Initial Catalog=Reservation;Integrated Security=True");

            SqlCommand sqlcommand = new SqlCommand();
            sqlcommand.Connection = SqlConnection;
            SqlConnection.Open();
            sqlcommand.CommandText = "Delete from employee where EMPLOYEEID = '" + textBox3.Text + "'";
            sqlcommand.ExecuteNonQuery();
            SqlConnection.Close();
            MessageBox.Show("DELETED SUCESSFULLY");
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'reservationDataSet.FLIGHT_INFO' table. You can move, or remove it, as needed.
            this.fLIGHT_INFOTableAdapter.Fill(this.reservationDataSet.FLIGHT_INFO);
            // TODO: This line of code loads data into the 'reservationDataSet.EMPLOYEE' table. You can move, or remove it, as needed.
            this.eMPLOYEETableAdapter.Fill(this.reservationDataSet.EMPLOYEE);

        }

        private void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
