﻿namespace Reservation
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            System.Windows.Forms.Label aIRCRAFTIDLabel;
            System.Windows.Forms.Label cAPACITYLabel;
            System.Windows.Forms.Label fLIGHT_IDLabel;
            System.Windows.Forms.Label dATELabel;
            this.reservationDataSet = new Reservation.ReservationDataSet();
            this.dISCOUNTBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dISCOUNTTableAdapter = new Reservation.ReservationDataSetTableAdapters.DISCOUNTTableAdapter();
            this.tableAdapterManager = new Reservation.ReservationDataSetTableAdapters.TableAdapterManager();
            this.dISCOUNTBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.dISCOUNTBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.aIRCRAFTBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.aIRCRAFTTableAdapter = new Reservation.ReservationDataSetTableAdapters.AIRCRAFTTableAdapter();
            this.aIRCRAFTIDTextBox = new System.Windows.Forms.TextBox();
            this.cAPACITYTextBox = new System.Windows.Forms.TextBox();
            this.fLIGHT_IDTextBox = new System.Windows.Forms.TextBox();
            this.dATEDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.aIRCRAFTDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            aIRCRAFTIDLabel = new System.Windows.Forms.Label();
            cAPACITYLabel = new System.Windows.Forms.Label();
            fLIGHT_IDLabel = new System.Windows.Forms.Label();
            dATELabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.reservationDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dISCOUNTBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dISCOUNTBindingNavigator)).BeginInit();
            this.dISCOUNTBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aIRCRAFTBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aIRCRAFTDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // reservationDataSet
            // 
            this.reservationDataSet.DataSetName = "ReservationDataSet";
            this.reservationDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dISCOUNTBindingSource
            // 
            this.dISCOUNTBindingSource.DataMember = "DISCOUNT";
            this.dISCOUNTBindingSource.DataSource = this.reservationDataSet;
            // 
            // dISCOUNTTableAdapter
            // 
            this.dISCOUNTTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AIRCRAFTTableAdapter = this.aIRCRAFTTableAdapter;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DEPENDANT_OFTableAdapter = null;
            this.tableAdapterManager.DESTINATIONTableAdapter = null;
            this.tableAdapterManager.DISCOUNTTableAdapter = this.dISCOUNTTableAdapter;
            this.tableAdapterManager.EMPLOYEETableAdapter = null;
            this.tableAdapterManager.FLIGHT_INFOTableAdapter = null;
            this.tableAdapterManager.HAVETableAdapter = null;
            this.tableAdapterManager.PASSENGERTableAdapter = null;
            this.tableAdapterManager.TICKETTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Reservation.ReservationDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // dISCOUNTBindingNavigator
            // 
            this.dISCOUNTBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.dISCOUNTBindingNavigator.BindingSource = this.dISCOUNTBindingSource;
            this.dISCOUNTBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.dISCOUNTBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.dISCOUNTBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.dISCOUNTBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.dISCOUNTBindingNavigatorSaveItem});
            this.dISCOUNTBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.dISCOUNTBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.dISCOUNTBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.dISCOUNTBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.dISCOUNTBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.dISCOUNTBindingNavigator.Name = "dISCOUNTBindingNavigator";
            this.dISCOUNTBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.dISCOUNTBindingNavigator.Size = new System.Drawing.Size(1380, 27);
            this.dISCOUNTBindingNavigator.TabIndex = 0;
            this.dISCOUNTBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(45, 24);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // dISCOUNTBindingNavigatorSaveItem
            // 
            this.dISCOUNTBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.dISCOUNTBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("dISCOUNTBindingNavigatorSaveItem.Image")));
            this.dISCOUNTBindingNavigatorSaveItem.Name = "dISCOUNTBindingNavigatorSaveItem";
            this.dISCOUNTBindingNavigatorSaveItem.Size = new System.Drawing.Size(24, 24);
            this.dISCOUNTBindingNavigatorSaveItem.Text = "Save Data";
            this.dISCOUNTBindingNavigatorSaveItem.Click += new System.EventHandler(this.DISCOUNTBindingNavigatorSaveItem_Click);
            // 
            // aIRCRAFTBindingSource
            // 
            this.aIRCRAFTBindingSource.DataMember = "AIRCRAFT";
            this.aIRCRAFTBindingSource.DataSource = this.reservationDataSet;
            // 
            // aIRCRAFTTableAdapter
            // 
            this.aIRCRAFTTableAdapter.ClearBeforeFill = true;
            // 
            // aIRCRAFTIDLabel
            // 
            aIRCRAFTIDLabel.AutoSize = true;
            aIRCRAFTIDLabel.Location = new System.Drawing.Point(103, 128);
            aIRCRAFTIDLabel.Name = "aIRCRAFTIDLabel";
            aIRCRAFTIDLabel.Size = new System.Drawing.Size(92, 17);
            aIRCRAFTIDLabel.TabIndex = 1;
            aIRCRAFTIDLabel.Text = "AIRCRAFTID:";
            // 
            // aIRCRAFTIDTextBox
            // 
            this.aIRCRAFTIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.aIRCRAFTBindingSource, "AIRCRAFTID", true));
            this.aIRCRAFTIDTextBox.Location = new System.Drawing.Point(201, 125);
            this.aIRCRAFTIDTextBox.Name = "aIRCRAFTIDTextBox";
            this.aIRCRAFTIDTextBox.Size = new System.Drawing.Size(200, 22);
            this.aIRCRAFTIDTextBox.TabIndex = 2;
            // 
            // cAPACITYLabel
            // 
            cAPACITYLabel.AutoSize = true;
            cAPACITYLabel.Location = new System.Drawing.Point(103, 156);
            cAPACITYLabel.Name = "cAPACITYLabel";
            cAPACITYLabel.Size = new System.Drawing.Size(78, 17);
            cAPACITYLabel.TabIndex = 3;
            cAPACITYLabel.Text = "CAPACITY:";
            // 
            // cAPACITYTextBox
            // 
            this.cAPACITYTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.aIRCRAFTBindingSource, "CAPACITY", true));
            this.cAPACITYTextBox.Location = new System.Drawing.Point(201, 153);
            this.cAPACITYTextBox.Name = "cAPACITYTextBox";
            this.cAPACITYTextBox.Size = new System.Drawing.Size(200, 22);
            this.cAPACITYTextBox.TabIndex = 4;
            // 
            // fLIGHT_IDLabel
            // 
            fLIGHT_IDLabel.AutoSize = true;
            fLIGHT_IDLabel.Location = new System.Drawing.Point(103, 184);
            fLIGHT_IDLabel.Name = "fLIGHT_IDLabel";
            fLIGHT_IDLabel.Size = new System.Drawing.Size(78, 17);
            fLIGHT_IDLabel.TabIndex = 5;
            fLIGHT_IDLabel.Text = "FLIGHT ID:";
            // 
            // fLIGHT_IDTextBox
            // 
            this.fLIGHT_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.aIRCRAFTBindingSource, "FLIGHT_ID", true));
            this.fLIGHT_IDTextBox.Location = new System.Drawing.Point(201, 181);
            this.fLIGHT_IDTextBox.Name = "fLIGHT_IDTextBox";
            this.fLIGHT_IDTextBox.Size = new System.Drawing.Size(200, 22);
            this.fLIGHT_IDTextBox.TabIndex = 6;
            // 
            // dATELabel
            // 
            dATELabel.AutoSize = true;
            dATELabel.Location = new System.Drawing.Point(103, 213);
            dATELabel.Name = "dATELabel";
            dATELabel.Size = new System.Drawing.Size(49, 17);
            dATELabel.TabIndex = 7;
            dATELabel.Text = "DATE:";
            // 
            // dATEDateTimePicker
            // 
            this.dATEDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.aIRCRAFTBindingSource, "DATE", true));
            this.dATEDateTimePicker.Location = new System.Drawing.Point(201, 209);
            this.dATEDateTimePicker.Name = "dATEDateTimePicker";
            this.dATEDateTimePicker.Size = new System.Drawing.Size(200, 22);
            this.dATEDateTimePicker.TabIndex = 8;
            // 
            // aIRCRAFTDataGridView
            // 
            this.aIRCRAFTDataGridView.AutoGenerateColumns = false;
            this.aIRCRAFTDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.aIRCRAFTDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.aIRCRAFTDataGridView.DataSource = this.aIRCRAFTBindingSource;
            this.aIRCRAFTDataGridView.Location = new System.Drawing.Point(579, 92);
            this.aIRCRAFTDataGridView.Name = "aIRCRAFTDataGridView";
            this.aIRCRAFTDataGridView.RowTemplate.Height = 24;
            this.aIRCRAFTDataGridView.Size = new System.Drawing.Size(445, 220);
            this.aIRCRAFTDataGridView.TabIndex = 9;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "AIRCRAFTID";
            this.dataGridViewTextBoxColumn1.HeaderText = "AIRCRAFTID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "CAPACITY";
            this.dataGridViewTextBoxColumn2.HeaderText = "CAPACITY";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "FLIGHT_ID";
            this.dataGridViewTextBoxColumn3.HeaderText = "FLIGHT_ID";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "DATE";
            this.dataGridViewTextBoxColumn4.HeaderText = "DATE";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1380, 450);
            this.Controls.Add(this.aIRCRAFTDataGridView);
            this.Controls.Add(aIRCRAFTIDLabel);
            this.Controls.Add(this.aIRCRAFTIDTextBox);
            this.Controls.Add(cAPACITYLabel);
            this.Controls.Add(this.cAPACITYTextBox);
            this.Controls.Add(fLIGHT_IDLabel);
            this.Controls.Add(this.fLIGHT_IDTextBox);
            this.Controls.Add(dATELabel);
            this.Controls.Add(this.dATEDateTimePicker);
            this.Controls.Add(this.dISCOUNTBindingNavigator);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.reservationDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dISCOUNTBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dISCOUNTBindingNavigator)).EndInit();
            this.dISCOUNTBindingNavigator.ResumeLayout(false);
            this.dISCOUNTBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aIRCRAFTBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aIRCRAFTDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ReservationDataSet reservationDataSet;
        private System.Windows.Forms.BindingSource dISCOUNTBindingSource;
        private ReservationDataSetTableAdapters.DISCOUNTTableAdapter dISCOUNTTableAdapter;
        private ReservationDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator dISCOUNTBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton dISCOUNTBindingNavigatorSaveItem;
        private ReservationDataSetTableAdapters.AIRCRAFTTableAdapter aIRCRAFTTableAdapter;
        private System.Windows.Forms.BindingSource aIRCRAFTBindingSource;
        private System.Windows.Forms.TextBox aIRCRAFTIDTextBox;
        private System.Windows.Forms.TextBox cAPACITYTextBox;
        private System.Windows.Forms.TextBox fLIGHT_IDTextBox;
        private System.Windows.Forms.DateTimePicker dATEDateTimePicker;
        private System.Windows.Forms.DataGridView aIRCRAFTDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    }
}