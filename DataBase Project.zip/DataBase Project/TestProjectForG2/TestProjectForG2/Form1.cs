﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestProjectForG2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();

            connection.ConnectionString = "Data Source=DESKTOP-JA4LV73;Initial Catalog= Mini-University;Integrated Security=True";
            SqlCommand Command = new SqlCommand("Insert Into Department values ( '" + textBox1.Text + "','" + textBox2.Text + "')", connection);

            connection.Open();
            MessageBox.Show(Command.CommandText);
            Command.ExecuteNonQuery();
            connection.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();

            connection.ConnectionString = "Data Source=DESKTOP-JA4LV73;Initial Catalog= Mini-University;Integrated Security=True";
            SqlCommand Command = new SqlCommand("update Department set Name = '" + textBox2.Text + "' where DeptCode = '" + textBox1.Text + "'", connection);

            connection.Open();
            MessageBox.Show(Command.CommandText);
            Command.ExecuteNonQuery();
            connection.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection();

            connection.ConnectionString = "Data Source=DESKTOP-JA4LV73;Initial Catalog= Mini-University;Integrated Security=True";
            SqlCommand Command = new SqlCommand("Delete From Department Where DeptCode = '" + textBox1.Text + "'", connection);

            connection.Open();
            MessageBox.Show(Command.CommandText);
            Command.ExecuteNonQuery();
            var x = Command.ExecuteReader();
            connection.Close();
        }
    }
}
